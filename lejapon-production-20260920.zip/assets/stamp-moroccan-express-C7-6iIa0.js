const s="/assets/stamp-moroccan-express-ClcM6eux.png";export{s};
