const a="/assets/tea-ceremony-vn6bzO5a.jpg";export{a as t};
