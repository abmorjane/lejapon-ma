const s="/assets/hero-fuji-Bu3cxcIY.jpg";export{s as h};
