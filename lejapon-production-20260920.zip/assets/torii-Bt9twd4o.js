const t="/assets/torii-6jM1Hcku.jpg";export{t};
