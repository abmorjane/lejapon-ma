const o="/assets/kyoto-alley-UD9w12tT.jpg";export{o as k};
