const s="/assets/tokyo-shibuya-DxbkMaen.jpg";export{s};
